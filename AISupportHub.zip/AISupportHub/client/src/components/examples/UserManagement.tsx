import { UserManagement } from "../UserManagement";

export default function UserManagementExample() {
  return (
    <div className="p-6">
      <UserManagement />
    </div>
  );
}
