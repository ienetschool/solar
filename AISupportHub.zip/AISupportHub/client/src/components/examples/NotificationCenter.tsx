import { NotificationCenter } from "../NotificationCenter";

export default function NotificationCenterExample() {
  return (
    <div className="p-6 flex justify-end">
      <NotificationCenter />
    </div>
  );
}
