import { Footer } from "../solar/Footer";

export default function FooterExample() {
  return <Footer />;
}
