import { FAQSection } from "../FAQSection";

export default function FAQSectionExample() {
  return (
    <div className="p-6 max-w-4xl">
      <FAQSection />
    </div>
  );
}
