import Home from "../../pages/solar/Home";

export default function HomePageExample() {
  return <Home />;
}
