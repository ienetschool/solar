import { AIChat } from "../solar/AIChat";

export default function AIChatExample() {
  return (
    <div className="h-screen bg-background">
      <AIChat />
    </div>
  );
}
